Public Key
===========

.. autoclass:: openfhe.PublicKey
    :members:
    :undoc-members:
    :show-inheritance:

Private Key
===========
.. autoclass:: openfhe.PrivateKey
    :members:
    :undoc-members:
    :show-inheritance:

KeyPair
=======
.. autoclass:: openfhe.KeyPair
    :members:
    :undoc-members:
    :show-inheritance:

