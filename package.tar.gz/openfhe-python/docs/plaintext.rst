Plaintext
=============

.. autoclass:: openfhe.Plaintext
    :members:
    :undoc-members:
    :show-inheritance: