BinFHEContext
----------------

.. autoclass:: openfhe.BinFHEContext
    :members:
    :undoc-members:
    :show-inheritance:

LWECiphertext
----------------
.. autoclass:: openfhe.LWECiphertext
    :members:
    :undoc-members:
    :show-inheritance:
    
LWEPrivateKey
----------------
.. autoclass:: openfhe.LWEPrivateKey
    :members:
    :undoc-members:
    :show-inheritance: