Ciphertext
==========

.. autoclass:: openfhe.Ciphertext
    :members:
    :undoc-members:
    :show-inheritance: