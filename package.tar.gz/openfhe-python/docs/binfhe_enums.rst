BinFHE enums
=============

Parameter Set
#############

.. autoclass:: openfhe.BINFHE_PARAMSET
    :members:
    :undoc-members:
    :show-inheritance:

BINFHE_METHOD
#############
.. autoclass:: openfhe.BINFHE_METHOD
    :members:
    :undoc-members:
    :show-inheritance:

BinFHE Output
#############
.. autoclass:: openfhe.BINFHE_OUTPUT
    :members:
    :undoc-members:
    :show-inheritance:

Binary Gates
#############
.. autoclass:: openfhe.BINGATE
    :members:
    :undoc-members:
    :show-inheritance:
